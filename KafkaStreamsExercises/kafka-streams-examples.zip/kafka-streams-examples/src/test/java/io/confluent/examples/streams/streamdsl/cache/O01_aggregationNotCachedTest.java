package io.confluent.examples.streams.streamdsl.cache;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.Windowed;
import org.apache.kafka.streams.test.TestRecord;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.time.*;
import java.util.*;

import static io.confluent.examples.streams.streamdsl.cache.O01_aggregationNotCached.getStreamsConfiguration;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Stream processing unit test of {@link O01_aggregationNotCached}, using TopologyTestDriver.
 *
 * See {@link O01_aggregationNotCached} for further documentation.
 */
@Slf4j
public class O01_aggregationNotCachedTest {
    private static final ZoneId zone = ZoneOffset.UTC;
    private TopologyTestDriver testDriver;
    private TestInputTopic<String, Long> testInputTopic;
    private TestOutputTopic<String, Long> testAggregatedOutputTopic;
    private TestOutputTopic<Windowed<String>, Long> testSessionWindowedCountOutputTopic;
    private StringSerializer stringSerializer = new StringSerializer();
    private LongSerializer longSerializer = new LongSerializer();
    private StringDeserializer stringDeserializer = new StringDeserializer();
    private LongDeserializer longDeserializer = new LongDeserializer();

    @Before
    public void setup() {
        final StreamsBuilder builder = new StreamsBuilder();

        // Create actual StreamBuilder topology
        O01_aggregationNotCached.createStream(builder);

        Topology topology = builder.build();

        System.out.println("\n||||||||||||||||||\n\n" + topology.describe() +
                "You can see it in http://zz85.github.io/kafka-streams-viz\n\n" +
                "Alternatively you can run ~/Downloads/apache-tomcat-9.0.39/bin/catalina.sh start\n" +
                "and use your local url http://localhost:8080/kafka-streams-viz/\n" +
                "If you want to play around, save the png graph topology obtained and open it in Chrome url " +
                "https://cloudapps.herokuapp.com/imagetoascii/" +
                "\n||||||||||||||||||\n");

        testDriver = new TopologyTestDriver(topology,
                               getStreamsConfiguration("localhost:9092"));

        testInputTopic =
                testDriver.createInputTopic(O01_aggregationNotCached.inputTopic,
                                            stringSerializer, longSerializer);
        testAggregatedOutputTopic =
                testDriver.createOutputTopic(O01_aggregationNotCached.outputTopic,
                        stringDeserializer, longDeserializer);
/*
        testSessionWindowedCountOutputTopic =
                testDriver.createOutputTopic(O01_aggregationNotCached.sessionWindowedCountOutTopic,
                        new TimeWindowedDeserializer<>(
                                stringDeserializer,
                                Duration.ofDays(1).toMillis()),
                        longDeserializer);
*/
    }

    @After
    public void tearDown() {
        try {
            testDriver.close();
        } catch (final RuntimeException e) {
            // https://issues.apache.org/jira/browse/KAFKA-6647 causes exception when executed in Windows, ignoring it
            // Logged stacktrace cannot be avoided
            System.out.println("Ignoring exception, test failing in Windows due this exception:" + e.getLocalizedMessage());
        }
    }

    /**
     *  Simple test validating several input records
     */
    @Test
    public void outputTopicMustContainInputTopicRecords() {
        List<TestRecord<String, Long>> inputValues =
                Arrays.asList(
                    new TestRecord<>("A",1L,
                            ZonedDateTime.of(2020, 1, 1, 16, 29, 0, 0, zone).toInstant())
                   ,new TestRecord<>("A",20L,
                            ZonedDateTime.of(2020, 1, 1, 16, 30, 0, 0, zone).toInstant())
                   ,new TestRecord<>("C",55L,
                            ZonedDateTime.of(2020, 1, 1, 16, 30, 0, 0, zone).toInstant())
                   ,new TestRecord<>("A",300L,
                            ZonedDateTime.of(2020, 1, 1, 16, 35, 0, 0, zone).toInstant())
                );

        List<KeyValue<String, Long>> expectedAggOutValues = Arrays.asList(
            new KeyValue<>("A", 1L)
           ,new KeyValue<>("A", 21L)
           ,new KeyValue<>("C", 55L)
           ,new KeyValue<>("A", 321L)
        );

        testInputTopic.pipeRecordList(inputValues);

        assertThat(testAggregatedOutputTopic.readKeyValuesToList(), equalTo(expectedAggOutValues));
        //No more output in topic
        assertTrue(testAggregatedOutputTopic.isEmpty());
    }
}
