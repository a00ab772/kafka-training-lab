package io.confluent.examples.streams.streamdsl.cache;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.Windowed;
import org.apache.kafka.streams.test.TestRecord;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.time.*;
import java.util.Arrays;
import java.util.List;

import static io.confluent.examples.streams.streamdsl.cache.O02_aggregationCached.getStreamsConfiguration;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Stream processing unit test of {@link O02_aggregationCached}, using TopologyTestDriver.
 *
 * See {@link O02_aggregationCached} for further documentation.
 */
@Slf4j
public class O02_aggregationCachedTest {
    private static final ZoneId zone = ZoneOffset.UTC;
    private TopologyTestDriver testDriver;
    private TestInputTopic<String, Long> testInputTopic;
    private TestOutputTopic<String, Long> testAggregatedOutputTopic;
    private TestOutputTopic<Windowed<String>, Long> testSessionWindowedCountOutputTopic;
    private StringSerializer stringSerializer = new StringSerializer();
    private LongSerializer longSerializer = new LongSerializer();
    private StringDeserializer stringDeserializer = new StringDeserializer();
    private LongDeserializer longDeserializer = new LongDeserializer();

    @Before
    public void setup() {
        final StreamsBuilder builder = new StreamsBuilder();

        // Create actual StreamBuilder topology
        O02_aggregationCached.createStream(builder);

        Topology topology = builder.build();

        System.out.println("\n||||||||||||||||||\n\n" + topology.describe() +
                "You can see it in http://zz85.github.io/kafka-streams-viz\n\n" +
                "Alternatively you can run ~/Downloads/apache-tomcat-9.0.39/bin/catalina.sh start\n" +
                "and use your local url http://localhost:8080/kafka-streams-viz/\n" +
                "If you want to play around, save the png graph topology obtained and open it in Chrome url " +
                "https://cloudapps.herokuapp.com/imagetoascii/" +
                "\n||||||||||||||||||\n");

        testDriver = new TopologyTestDriver(topology,
                               getStreamsConfiguration("localhost:9092"));

        testInputTopic =
                testDriver.createInputTopic(O02_aggregationCached.inputTopic,
                                            stringSerializer, longSerializer);
        testAggregatedOutputTopic =
                testDriver.createOutputTopic(O02_aggregationCached.outputTopic,
                        stringDeserializer, longDeserializer);
/*
        testSessionWindowedCountOutputTopic =
                testDriver.createOutputTopic(O02_aggregationCached.sessionWindowedCountOutTopic,
                        new TimeWindowedDeserializer<>(
                                stringDeserializer,
                                Duration.ofDays(1).toMillis()),
                        longDeserializer);
*/
    }

    @After
    public void tearDown() {
        try {
            testDriver.close();
        } catch (final RuntimeException e) {
            // https://issues.apache.org/jira/browse/KAFKA-6647 causes exception when executed in Windows, ignoring it
            // Logged stacktrace cannot be avoided
            System.out.println("Ignoring exception, test failing in Windows due this exception:" + e.getLocalizedMessage());
        }
    }

    /**
     *  Simple test validating several input records
     */
    @Test
    public void outputTopicMustContainInputTopicRecords() {
/*        List<TestRecord<String, Long>> inputValues =
                Arrays.asList(
                    new TestRecord<>("A",1L,
                            ZonedDateTime.of(2020, 1, 1, 16, 29, 0, 0, zone).toInstant())
                   ,new TestRecord<>("A",20L,
                            ZonedDateTime.of(2020, 1, 1, 16, 30, 0, 0, zone).toInstant())
                   ,new TestRecord<>("C",55L,
                            ZonedDateTime.of(2020, 1, 1, 16, 30, 0, 0, zone).toInstant())
                   ,new TestRecord<>("A",300L,
                            ZonedDateTime.of(2020, 1, 1, 16, 31, 0, 0, zone).toInstant())
                );*/

        List<KeyValue<String, Long>> inputValues = Arrays.asList(
                new KeyValue<>("A", 1L)
                ,new KeyValue<>("A", 20L)
                ,new KeyValue<>("C", 55L)
                ,new KeyValue<>("A", 300L)
        );

        List<KeyValue<String, Long>> expectedAggOutValues = Arrays.asList(
            new KeyValue<>("A", 1L)
           ,new KeyValue<>("A", 21L)
           ,new KeyValue<>("C", 55L)
           ,new KeyValue<>("A", 321L)
        );

        testInputTopic.pipeKeyValueList(inputValues,
                Instant.ofEpochMilli(0), Duration.ofMillis(100));

        assertThat(testAggregatedOutputTopic.readKeyValuesToList(), equalTo(expectedAggOutValues));
        //No more output in topic
        assertTrue(testAggregatedOutputTopic.isEmpty());
    }
}
